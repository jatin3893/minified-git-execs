#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/mingw32/lib"
XML2_LIBS="-lxml2 -L/mingw32/lib -lz -L/mingw32/lib -llzma   -liconv   "
XML2_INCLUDEDIR="-I/mingw32/include/libxml2"
MODULE_VERSION="xml2-2.9.12"

